package view;

import dao.BarangDAO;
import model.Barang;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class FormBarang extends JFrame {
    private static final long serialVersionUID = 1L;

    // Nomor 4: Komponen Swing
    private final JTextField txtKode = new JTextField(20);
    private final JTextField txtNama = new JTextField(20);
    private final JComboBox<String> cmbKategori = new JComboBox<>(new String[]{"Komputer", "Jaringan", "Alat Ukur"});
    private final JTextField txtStok = new JTextField("0", 20);

    private final JButton btnSimpan = new JButton("Simpan");
    private final JButton btnUbah = new JButton("Ubah");
    private final JButton btnHapus = new JButton("Hapus");
    private final JButton btnBersihkan = new JButton("Bersihkan");

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Kode Barang", "Nama Barang", "Kategori", "Stok"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelBarang = new JTable(model);

    public FormBarang() {
        super("Form Pengelolaan Data Barang Laboratorium");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        susunTampilan();
        pasangAksi();
        loadTableData(); // Nomor 6: Tampilkan data saat form dibuka
        pack();
        setMinimumSize(new Dimension(750, 520));
        setLocationRelativeTo(null);
    }

    private void susunTampilan() {
        JPanel utama = new JPanel(new BorderLayout(10, 10));
        utama.setBorder(new EmptyBorder(15, 15, 15, 15));
        utama.setBackground(new Color(245, 247, 250));
        setContentPane(utama);

        JLabel judul = new JLabel("PENGELOLAAN DATA BARANG LABORATORIUM");
        judul.setFont(new Font("SansSerif", Font.BOLD, 18));
        judul.setForeground(new Color(30, 60, 90));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(judul, BorderLayout.CENTER);
        utama.add(header, BorderLayout.NORTH);

        // Panel Form Input
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Input Data Barang"));
        form.setBackground(Color.WHITE);

        tambahBarisForm(form, 0, "Kode Barang", txtKode);
        tambahBarisForm(form, 1, "Nama Barang", txtNama);
        tambahBarisForm(form, 2, "Kategori", cmbKategori);
        tambahBarisForm(form, 3, "Stok", txtStok);

        // Panel Tombol
        JPanel panelTombol = new JPanel();
        panelTombol.setOpaque(false);
        panelTombol.add(btnSimpan);
        panelTombol.add(btnUbah);
        panelTombol.add(btnHapus);
        panelTombol.add(btnBersihkan);

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.gridy = 4;
        g.gridwidth = 2;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(10, 5, 5, 5);
        form.add(panelTombol, g);

        // Tabel Daftar Barang
        tabelBarang.setRowHeight(24);
        tabelBarang.setAutoCreateRowSorter(true);
        JScrollPane scroll = new JScrollPane(tabelBarang);
        scroll.setPreferredSize(new Dimension(700, 180));
        scroll.setBorder(BorderFactory.createTitledBorder("Daftar Barang"));

        JPanel tengah = new JPanel(new BorderLayout(10, 10));
        tengah.setOpaque(false);
        tengah.add(form, BorderLayout.NORTH);
        tengah.add(scroll, BorderLayout.CENTER);

        utama.add(tengah, BorderLayout.CENTER);
    }

    private void tambahBarisForm(JPanel panel, int baris, String labelText, JComponent komponen) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = baris;
        g.insets = new Insets(6, 8, 6, 8);
        g.anchor = GridBagConstraints.WEST;

        g.gridx = 0;
        panel.add(new JLabel(labelText), g);

        g.gridx = 1;
        g.weightx = 1.0;
        g.fill = GridBagConstraints.HORIZONTAL;
        panel.add(komponen, g);
    }

    private void pasangAksi() {
        // Nomor 5: Tombol Simpan
        btnSimpan.addActionListener(e -> simpanData());

        // Nomor 7: Tombol Ubah
        btnUbah.addActionListener(e -> ubahData());

        // Nomor 7: Tombol Hapus dengan Konfirmasi
        btnHapus.addActionListener(e -> hapusData());

        // Tombol Bersihkan
        btnBersihkan.addActionListener(e -> bersihkanForm());

        // Nomor 6: Klik baris di JTable, data muncul kembali di form
        tabelBarang.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = tabelBarang.getSelectedRow();
                if (row != -1) {
                    txtKode.setText(tabelBarang.getValueAt(row, 0).toString());
                    txtNama.setText(tabelBarang.getValueAt(row, 1).toString());
                    cmbKategori.setSelectedItem(tabelBarang.getValueAt(row, 2).toString());
                    txtStok.setText(tabelBarang.getValueAt(row, 3).toString());
                    txtKode.setEditable(false); // Kunci kode saat mode edit
                }
            }
        });
    }

    // Nomor 6: Tampilkan data barang ke JTable saat form dibuka & setelah disimpan
    public void loadTableData() {
        model.setRowCount(0);
        BarangDAO dao = new BarangDAO();
        List<Barang> list = dao.getAllData();
        for (Barang b : list) {
            model.addRow(new Object[]{
                b.getKodeBarang(),
                b.getNamaBarang(),
                b.getKategori(),
                b.getStok()
            });
        }
    }

    // Nomor 5: Logika Simpan dengan Validasi & PreparedStatement
    private void simpanData() {
        String kode = txtKode.getText().trim();
        String nama = txtNama.getText().trim();
        String kategori = cmbKategori.getSelectedItem().toString();

        if (kode.isEmpty() || nama.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kode dan Nama Barang tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int stok = Integer.parseInt(txtStok.getText().trim());
            if (stok < 0) {
                JOptionPane.showMessageDialog(this, "Stok harus berupa angka >= 0!", "Error Validasi", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Barang barang = new Barang(kode, nama, kategori, stok);
            BarangDAO dao = new BarangDAO();
            if (dao.insertData(barang)) {
                JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
                loadTableData();
                bersihkanForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menyimpan data (Kemungkinan Kode Barang sudah ada).", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok harus diisi dengan angka yang valid (bukan huruf)!", "Error Validasi", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Nomor 7: Logika Ubah Data
    private void ubahData() {
        String kode = txtKode.getText().trim();
        String nama = txtNama.getText().trim();
        String kategori = cmbKategori.getSelectedItem().toString();

        if (kode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pilih data dari tabel terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int stok = Integer.parseInt(txtStok.getText().trim());
            if (stok < 0) {
                JOptionPane.showMessageDialog(this, "Stok harus berupa angka >= 0!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Barang barang = new Barang(kode, nama, kategori, stok);
            BarangDAO dao = new BarangDAO();
            if (dao.updateData(barang)) {
                JOptionPane.showMessageDialog(this, "Data berhasil diubah!");
                loadTableData();
                bersihkanForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal mengubah data!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok harus diisi dengan angka yang valid!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Nomor 7: Logika Hapus Data dengan Konfirmasi
    private void hapusData() {
        String kode = txtKode.getText().trim();
        if (kode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pilih data dari tabel yang ingin dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus barang dengan kode " + kode + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            BarangDAO dao = new BarangDAO();
            if (dao.deleteData(kode)) {
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                loadTableData();
                bersihkanForm();
            } else {
                JOptionPane.showMessageDialog(this, "Gagal menghapus data!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void bersihkanForm() {
        txtKode.setText("");
        txtNama.setText("");
        txtStok.setText("0");
        cmbKategori.setSelectedIndex(0);
        txtKode.setEditable(true);
        txtKode.requestFocusInWindow();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FormBarang().setVisible(true));
    }
}