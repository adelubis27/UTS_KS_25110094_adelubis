package dao;

import database.Koneksi;
import model.Barang;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BarangDAO {
    
    // Nomor 5: Simpan dengan PreparedStatement
    public boolean insertData(Barang barang) {
        String query = "INSERT INTO barang (kode_barang, nama_barang, kategori, stok) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = Koneksi.getConnection().prepareStatement(query)) {
            ps.setString(1, barang.getKodeBarang());
            ps.setString(2, barang.getNamaBarang());
            ps.setString(3, barang.getKategori());
            ps.setInt(4, barang.getStok());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Nomor 7: Ubah Data berdasarkan kode barang
    public boolean updateData(Barang barang) {
        String query = "UPDATE barang SET nama_barang = ?, kategori = ?, stok = ? WHERE kode_barang = ?";
        try (PreparedStatement ps = Koneksi.getConnection().prepareStatement(query)) {
            ps.setString(1, barang.getNamaBarang());
            ps.setString(2, barang.getKategori());
            ps.setInt(3, barang.getStok());
            ps.setString(4, barang.getKodeBarang());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Nomor 7: Hapus Data berdasarkan kode barang
    public boolean deleteData(String kodeBarang) {
        String query = "DELETE FROM barang WHERE kode_barang = ?";
        try (PreparedStatement ps = Koneksi.getConnection().prepareStatement(query)) {
            ps.setString(1, kodeBarang);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Nomor 6: Ambil Semua Data untuk JTable
    public List<Barang> getAllData() {
        List<Barang> list = new ArrayList<>();
        String query = "SELECT * FROM barang";
        try (Statement st = Koneksi.getConnection().createStatement();
             ResultSet rs = st.executeQuery(query)) {
            while (rs.next()) {
                Barang b = new Barang(
                    rs.getString("kode_barang"),
                    rs.getString("nama_barang"),
                    rs.getString("kategori"),
                    rs.getInt("stok")
                );
                list.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}